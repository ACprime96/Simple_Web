import nltk
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer, CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import pickle
# uncomment the below line once to download stop words
# nltk.download('stopwords')

from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english", ignore_stopwords=True)


class StemmedCountVectorizer(CountVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedCountVectorizer, self).build_analyzer()
        return lambda doc: ([stemmer.stem(w) for w in analyzer(doc)])


stemmed_count_vect = StemmedCountVectorizer(stop_words='english')
text_mnb_stemmed = Pipeline([('vect', stemmed_count_vect), ('tfidf', TfidfTransformer()), ('mnb', MultinomialNB(fit_prior=False))])


def get_output(input_sent, model_file='Models/Stem_mnb.sav'):
    loaded_model = pickle.load(open(model_file, 'rb'))
    sentence_Style = loaded_model.predict(input_sent)[0]
    formal_score, informal_score = loaded_model.predict_proba(input_sent)[0]
    return sentence_Style, formal_score, informal_score
