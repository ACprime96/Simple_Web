from flask import Flask, request
from rule_based import preprocess
from best_classifier import StemmedCountVectorizer, get_output

app = Flask(__name__)

@app.route("/translate", methods=['POST', 'GET'])
def index():
    if request.method == 'GET':
        inp_sent = request.values.get('inp_sent')
        print("INPUT SENTENCE:  ",request.values.get('inp_sent'))
        op_sent = inp_sent #this only reference
        inp_sent_rule = preprocess(inp_sent)
        print("PREPROCESSED SENTENCE:  ", inp_sent_rule)
        print("Class of INPUT SENTENCE:  ", get_output([inp_sent_rule]))
        sent_type, formal_score, informal_score = get_output([inp_sent_rule])
        result = """{ "op_sent":"+op_sent+","sent_type": " + sent_type + ", "formal_score":" + str(formal_score) +  ", "informal_score":" + str(informal_score) + "}"""
        print(result)
        return result

if __name__ == '__main__':
    app.run(host='0.0.0.0')
