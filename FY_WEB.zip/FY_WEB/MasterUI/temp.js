var donut_temp = document.getElementById("sty_donut_class").getContext("2d");
var donut = new Chart(donut_temp).Doughnut(
  [
    {
      value: 300,
      color:"#F7464A",
      highlight: "#FF5A5E",
      label: "Red"
    },
    {
      value: 50,
      color: "#46BFBD",
      highlight: "#5AD3D1",
      label: "Green"
    },
    {
      value: 100,
      color: "#FDB45C",
      highlight: "#FFC870",
      label: "Yellow"
    }
  ],
  {
    segmentShowStroke : true,
    segmentStrokeColor : "#fff",
    segmentStrokeWidth : 2,
    percentageInnerCutout : 50,
    animationSteps : 100,
    animationEasing : "easeOutBounce",
    animateRotate : true,
    animateScale : false,
    responsive: true,
    maintainAspectRatio: true,
    showScale: true,
    animateScale: true
  });
{ 'op_sent':What in the world is it? ,'sent_type': formal, 'formal_score':0.571153762077559, 'informal_score':0.42884623792244114}
